# Scandi Slider 2.0

Scandi Slider 2.0 allows displaying your banner images and videos in a sliding carousel.
