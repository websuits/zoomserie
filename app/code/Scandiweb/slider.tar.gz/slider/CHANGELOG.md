Scandiweb_Slider changelog
========================
1.0.15
- Adding two separate image fields - desktop and mobile images

1.0.13
- Adding preparation of images for srcsets

1.0.10
- Fixed slider map drawing issue
- Created widget
- Updated 3rd party draw map library

1.0.9:
- Added support for php 7.1

1.0.7:
- Added ability to render widget from CMS block

1.0.6:
- Added configuration option for extra wide first slide block

1.0.5:
- Fixed wysiwyg content output for slider text

1.0.4:
- Added support for multiple images and embed codes on a slide

1.0.3:
- Updated slick slide js

1.0.2:
- Moved configuration to the Scandiweb menu

1.0.1:
- added PHP7 compatibility
