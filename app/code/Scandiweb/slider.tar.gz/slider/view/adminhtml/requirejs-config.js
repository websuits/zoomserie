var config = {
    paths: {
        'scandiweb/canvas-area-draw': 'Scandiweb_Slider/js/canvas-area-draw'
    },
    shim: {
        'scandiweb/canvas-area-draw': {
            deps: ['jquery']
        }
    }
};
