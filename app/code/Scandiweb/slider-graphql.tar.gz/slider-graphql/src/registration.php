<?php
/**
 * Scandiweb_SliderGraphQl
 *
 * @category    Scandiweb
 * @package     Scandiweb_SliderGraphQl
 * @author      Kriss Andrejevs <info@scandiweb.com>
 * @copyright   Copyright (c) 2018 Scandiweb, Ltd (https://scandiweb.com)
 */

Magento\Framework\Component\ComponentRegistrar::register(
    Magento\Framework\Component\ComponentRegistrar::MODULE,
    'ScandiPWA_SliderGraphQl',
    __DIR__
);
