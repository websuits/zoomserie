# ScandiPWA_SliderGraphQl

This module is extending ScandiPWA_Slider to implement graphQL query resolvers for data fetching.

## How to use?

### In admin panel

Please refer to [ScandiPWA_Slider](https://github.com/scandipwa/slider) to get admin panel instructions.

### Via GraphQL endpoint

Please refer to [schema.graphqls](./src/etc/schema.graphqls) to see all available fields to query.
